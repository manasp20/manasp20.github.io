# PRD: AI Support Triage Agent

**Author:** Manaswini Pisipati · **Status:** Prototype · **Stack:** Python, pytest, Git

## 1. Problem
Support teams get a mix of routine and risky requests. Automating routine ones saves time, but a confident wrong answer or wrong action costs customer trust. The product question: **when should the agent answer, ask, or hand off to a person?**

## 2. Users
- **Customer:** wants a fast, correct answer, or a quick path to a human.
- **Support agent (human):** wants escalated cases with context already gathered.
- **Support lead:** wants to see how often the AI is right and why it escalates.

## 3. Goals and non-goals
**Goals:** classify requests; answer only from approved knowledge; escalate what it cannot handle; measure itself.
**Non-goals:** acting on accounts without approval; answering from the open internet; replacing human agents.

## 4. Key requirements
| # | Requirement | Acceptance criterion |
|---|---|---|
| R1 | Classify each request into an intent | Intent matches the labeled intent on the golden set |
| R2 | Answer only from the approved knowledge base | Every answer cites a knowledge source; no source means no answer |
| R3 | Ask a clarifying question when required details are missing | Agent asks instead of guessing on incomplete requests |
| R4 | Escalate out-of-scope, low-confidence or sensitive requests | Escalated cases include intent, summary and what was tried |
| R5 | Never take an action it is not permitted to take | Disallowed actions are refused and escalated in tests |

## 5. Failure modes
| Failure | Detection | System response |
|---|---|---|
| Wrong intent | Golden-set mismatch | Low-confidence intents route to clarify or escalate |
| Answer not in knowledge base | Retrieval returns nothing relevant | Escalate; do not improvise |
| Missing parameters | Required field check | Clarifying question |
| Wrong action taken | Action test cases | Block and escalate |
| Over-escalation | Escalation rate review | Tune thresholds; review samples |

## 6. Metrics
Intent accuracy · action accuracy · escalation accuracy (escalated when it should, answered when it should) · over-escalation rate · outcome accuracy.

## 7. Evaluation plan
A golden evaluation suite in pytest. Each case has an input, expected intent, expected action and expected escalation decision.
**Results:** _fill in from your latest run (n cases, each metric, top failures, what you changed)._

## 8. Risks and open questions
- How large and varied must the golden set be before the numbers mean something?
- Where should confidence thresholds sit for each intent's risk level?

## 9. Next steps
Expand the golden set, add a review queue for escalated cases, add CI so tests run on every commit.
