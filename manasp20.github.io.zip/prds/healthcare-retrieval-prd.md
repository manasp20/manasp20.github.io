# PRD: AI Healthcare Knowledge Retrieval

**Author:** Manaswini Pisipati · **Status:** Academic prototype · **Stack:** GPT-4, Mistral, RAG, GraphRAG, Neo4j, ChromaDB

## 1. Problem
Keyword and plain vector search miss how medical concepts relate: which medications treat a condition, and which treatments go with which. Answers to health questions must be grounded in sources, not guessed.

## 2. Users
- **Learner or analyst** exploring health topics who needs sourced, relationship-aware answers.
- **Reviewer** who needs to check where an answer came from.

## 3. Goals and non-goals
**Goals:** link conditions, medications and treatments in a knowledge graph; combine graph and vector retrieval; show sources; check answer accuracy.
**Non-goals:** clinical advice or diagnosis; any use with real patient data.

## 4. Key requirements
| # | Requirement | Acceptance criterion |
|---|---|---|
| R1 | Build a graph of conditions, medications and treatments | Relationships are queryable in Neo4j |
| R2 | Retrieve with vector search (ChromaDB) and graph traversal | Retrieved context includes related entities, not just similar text |
| R3 | Generate answers only from retrieved context | Each answer links to its retrieved sources |
| R4 | Compare RAG and GraphRAG | Same test questions run on both and scored |
| R5 | Decline when context is insufficient | Out-of-scope questions return "not enough information" |

## 5. Failure modes
Hallucinated drug or condition links · stale or incomplete source data · retrieval returns related but wrong entities · answer sounds like medical advice. Mitigation: grounding checks, a visible disclaimer, a human-reviewed question set.

## 6. Metrics
Answer accuracy against a reviewed question set · groundedness (claims supported by sources) · RAG vs GraphRAG difference · refusal correctness.

## 7. Evaluation plan
A fixed set of questions with reference answers, scored by a reviewer, and run on both retrieval approaches.
**Results:** _fill in from your accuracy check (n questions, RAG vs GraphRAG, notable failures)._

## 8. Risks and open questions
Data licensing and quality of sources; how to keep the graph current; whether graph structure improves answers enough to justify the added complexity.
