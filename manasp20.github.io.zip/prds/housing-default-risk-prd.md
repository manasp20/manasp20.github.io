# PRD: OneApp Guarantee Housing Model (Capstone)

**Author:** Manaswini Pisipati · **Context:** Portland State University capstone · **Stack:** Python, SQL, Power BI, machine learning

## 1. Problem
A rental guarantee program needs to understand which tenants and areas carry higher default risk, so it can price and manage that risk responsibly.

## 2. Users
- **Program stakeholders** who decide eligibility, pricing and outreach.
- **Analysts** who need to trust and reuse the model.

## 3. Goals and non-goals
**Goals:** predict tenant default risk from Census, Eviction Lab and economic data; explain the main drivers; present clear recommendations.
**Non-goals:** automated approve/deny decisions; use of protected attributes to discriminate.

## 4. Key requirements
| # | Requirement | Acceptance criterion |
|---|---|---|
| R1 | Combine Census, Eviction Lab and economic data | One cleaned analysis dataset with documented joins |
| R2 | Predict default risk | Model validated on held-out data |
| R3 | Explain the drivers | Dashboard shows which factors matter; rent burden above 30% is the main driver |
| R4 | Present to non-technical stakeholders | Findings and recommendations delivered in a technical presentation |

## 5. Risks
Fairness and bias in housing decisions · area-level data standing in for individuals · data gaps and stale data · over-reliance on a single score. Mitigation: human review of decisions and a documented limitations section.

## 6. Metrics
Model performance on held-out data (**fill in your measured metric**) · stakeholder adoption of recommendations · stability of drivers across data splits.

## 7. Next steps
Fairness review, monitoring for drift, a pilot with human oversight.
